<?php

class Shipperhq_Calendar_Block_Adminhtml_Sales_Order_Create_Shipping_Method_Calendar
    extends Shipperhq_Calendar_Block_Calendar
{
    
}
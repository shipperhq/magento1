<?php

/*
 * Shipper HQ
 *
 * @category ShipperHQ
 * @package ShipperHQ_Shipper
 * @copyright Copyright (c) 2020 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */

/* @var $this Mage_Core_Model_Resource_Setup */
/*
 * No upgrade required between 0.0.15-0.0.16 as the change involved moving attributes from ShipperMage to ShipperFreight
 *
 */

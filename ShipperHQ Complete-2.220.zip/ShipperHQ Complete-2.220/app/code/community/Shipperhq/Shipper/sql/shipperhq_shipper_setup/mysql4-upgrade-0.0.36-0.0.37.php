<?php

/*
 * Shipper HQ
 *
 * @category ShipperHQ
 * @package ShipperHQ_Shipper
 * @copyright Copyright (c) 2020 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */

/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;

$installer->startSetup();

/* ------ shipperhq_hs_code -------- */
$this->addAttribute('catalog_product', 'shipperhq_hs_code', array(
    'type'                     => 'text',
    'input'                    => 'text',
    'label'                    => 'HS Code',
    'global'                   => false,
    'visible'                  => 1,
    'required'                 => 0,
    'visible_on_front'         => 0,
    'is_html_allowed_on_front' => 0,
    'searchable'               => 0,
    'filterable'               => 0,
    'comparable'               => 0,
    'unique'                   => false,
    'used_in_product_listing'  => false,
    'user_defined'             => true,
    'note'                     => 'Only required to support Cross Border Functionality'
));

$text = Mage::helper('wsalogger')->getNewVersion() > 10 ? Varien_Db_Ddl_Table::TYPE_TEXT : 'text';

$customsMessage = array(
    'type' => $text,
    'length'	=> 80,
    'comment' => 'Shipperhq Customs Message',
    'nullable' => 'true',
);

if(!$installer->getConnection()->tableColumnExists($installer->getTable('sales/quote_address_shipping_rate'), 'customs_message')){
    $installer->getConnection()->addColumn($installer->getTable('sales/quote_address_shipping_rate'), 'customs_message', $customsMessage);
}

$installer->endSetup();



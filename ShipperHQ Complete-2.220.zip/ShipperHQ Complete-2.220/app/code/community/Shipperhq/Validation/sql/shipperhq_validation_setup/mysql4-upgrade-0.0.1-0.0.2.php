<?php

/*
 * Shipper HQ
 *
 * @category ShipperHQ
 * @package shq
 * @copyright Copyright (c) 2020 Zowta LTD and Zowta LLC (http://www.ShipperHQ.com)
 * @license http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * @author ShipperHQ Team sales@shipperhq.com
 */

/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;
$installer->startSetup();


if($installer->getAttribute('customer_address', 'address_valid')) {
    $installer->updateAttribute('customer_address', 'address_valid', array('source_model' =>
        'shipperhq_shipper/source_validation_result'));
}

$installer->endSetup();

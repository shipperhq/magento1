<?php

namespace ShipperHQ\WS\Response\UPS\Registration;

/**
 * Class UPSRegistrationResponse
 *
 * @package ShipperHQ\WS\Response\UPS\Registration
 */
class UPSRegistrationResponse extends \ShipperHQ\WS\Response\AbstractWebServiceResponse implements \ShipperHQ\WS\Response\WebServiceResponse
{

}

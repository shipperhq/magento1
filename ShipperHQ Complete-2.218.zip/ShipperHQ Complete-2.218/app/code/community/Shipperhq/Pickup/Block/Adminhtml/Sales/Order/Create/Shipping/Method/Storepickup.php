<?php

class Shipperhq_Pickup_Block_Adminhtml_Sales_Order_Create_Shipping_Method_Storepickup
    extends Shipperhq_Pickup_Block_Storepickup
{
    
}
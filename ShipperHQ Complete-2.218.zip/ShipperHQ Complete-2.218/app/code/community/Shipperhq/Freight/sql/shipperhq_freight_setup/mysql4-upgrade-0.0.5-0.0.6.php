<?php
/* @var $installer Mage_Core_Model_Resource_Setup */

/*
 * No upgrade required. Changes were to remove attributes to ShipperHQ base installation script
 */
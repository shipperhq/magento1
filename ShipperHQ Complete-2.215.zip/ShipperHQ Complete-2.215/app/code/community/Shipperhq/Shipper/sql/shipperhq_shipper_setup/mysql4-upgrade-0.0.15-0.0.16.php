<?php
/* @var $this Mage_Core_Model_Resource_Setup */
/*
 * No upgrade required between 0.0.15-0.0.16 as the change involved moving attributes from ShipperMage to ShipperFreight
 *
 */
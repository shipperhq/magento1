<?php

namespace ShipperHQ\WS\Request\Rate;
use ShipperHQ\Shipping\Address;

include_once 'ShipperHQ/WS/Request/AbstractWebServiceRequest.php';
include_once 'ShipperHQ/WS/Request/WebServiceRequest.php';

/**
 * Class RateRequest
 *
 * @package ShipperHQ\WS\Request\Rate
 */
class InfoRequest extends \ShipperHQ\WS\Request\AbstractWebServiceRequest implements \ShipperHQ\WS\Request\WebServiceRequest
{
   /* function __construct()
    {

    }*/


}
